<?php 




$data = file_get_contents("php://input");
$t=time();
//file_put_contents("request".$t.".txt", $data);
$url = "http://my1.vvvxzml.com/Up.aspx";
$res = http($url,'POST',$data);
//file_put_contents("response".$t.".txt", $res);
echo $res;



/**
     * 封装 curl 访问
     * @param $url
     * @param $method
     * @param null $data
     * @return array
     */
 function http($url, $method, $data = null)
{
    $result = array();
    try {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, getHeaders());
        if ($data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $responce = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        ob_clean();
        if ($code == 200) {            
            $result = $responce;
        } else {
            $result = "有错误发生！错误代码：" . $code . ($responce?"\n错误信息如下：\n" . json_encode($responce):'');
        }
    } catch (Exception $e) {
        $result = '有异常发生：' . $e->getMessage();
    }
    return $result;
}
    /**
     * 组织请求头
     * @return array
     */
function getHeaders()
{
    $headers = array();
    $headers[] = 'Content-Type: application/octet-stream';
    $headers[] = 'Connection: keep-alive';
    return $headers;
}